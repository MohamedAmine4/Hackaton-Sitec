package com.example.smart_waste_manager_mobile_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
